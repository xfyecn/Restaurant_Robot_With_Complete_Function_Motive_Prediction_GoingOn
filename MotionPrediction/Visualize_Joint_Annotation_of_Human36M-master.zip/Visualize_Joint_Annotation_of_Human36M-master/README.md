# Visualize Joints Annotations of Human36M Dataset

## First of all

The repo is used by author to visualize Human3.6M images with joints annotations.  
Code in this repo is totally in a mess and maybe hard to read.  
Actually ,I have to admit that this repo is published because the author is too poor to afford a private account.   
If you are still  interested in this repo, Let's go on.  

## How to run the code 

### Environments
python2.7
```bash
pip install opencv-python h5py numpy 
```

### Edit path

Edit annotation and image path in `test.py`Line114-115  

### Visualize

run `python test.py`

